$(document).ready(function(){
    $('#time').click(function(){
        alert();
    });

    $('#position').click(function(){
        alert();

    });
});